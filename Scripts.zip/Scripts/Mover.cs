﻿using UnityEngine;
using System.Collections;

public class Mover : MonoBehaviour
{
    public float speed;
    private Rigidbody rb;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        //forward is in reference to the local z axis of the bolt object
        rb.velocity = transform.forward * speed;
    }
}
