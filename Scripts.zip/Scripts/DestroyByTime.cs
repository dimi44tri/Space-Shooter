﻿using UnityEngine;
using System.Collections;

public class DestroyByTime : MonoBehaviour
{
    public float lifetime;

    //destroy game object code is attached to after a certain time has passed of being instantiated
    void Start() { Destroy(gameObject, lifetime); }
}
