﻿using UnityEngine;
using System.Collections;

public class DestroyByContact : MonoBehaviour {

    public GameObject explosion;
    public GameObject playerExplosion;
    public int scoreValue;
    private GameController gameController; //used to refernece the specific game controller assigned in the component from asteroid object

    void Start()
    {
        //allows all copies of asteroids to link to the instance of Game Controller object in scene
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");

        if(gameControllerObject != null)
        {
            gameController = gameControllerObject.GetComponent<GameController>();
        }
        else
        {
            Debug.Log ("Cannot find 'GameController' script");
        }
    }

    void OnTriggerEnter(Collider other)
    {
        //Debug.Log(other.gameObject); <--debugger to display errors when running play mode
        if(other.tag == "Boundary") { return; }
        Instantiate(explosion, transform.position, transform.rotation);

        if(other.tag == "Player")
        {
            Instantiate(playerExplosion, other.transform.position, other.transform.rotation);
            gameController.GameOver();
        }
        
        Destroy(other.gameObject); //<--destroy laser upon contact
        Destroy(gameObject); //destroy asteroid
        gameController.AddScore(scoreValue);
    }
}
