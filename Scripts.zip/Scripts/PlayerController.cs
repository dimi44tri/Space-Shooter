﻿//*find out why the movement contraints in the code aren't being followed completely in engine

using UnityEngine;
using System.Collections;

[System.Serializable] //<-- Makes the below class show up as a new property in the unity inspector
public class Boundary
{
    public float xMin, xMax, zMin, zMax;
}

// ':' is symbol for class inheritance
public class PlayerController : MonoBehaviour {

    //Rigidbody variable to capture the same-named component from Player sphere object in unity
    public float speed;
    public float tilt;
    public float fireRate;
    private float nextFire;

    public Boundary bounds;
    public GameObject shot; //GameObject type allows me to add object in engine directly to this slot
    public AudioSource laserSfx;
    public Transform shotSpawn; //Unity can refernece the transform component of Bolt directly instead of through a GameObject type
    
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        laserSfx = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (Input.GetButton("Fire1") && Time.time > nextFire) //condition to adjust rate/timing of shots
        {
            nextFire = Time.time + fireRate;
            /*GameObject clone = code below if I want to save a reference to the new object being instantiated*/
            Instantiate(shot, shotSpawn.position, shotSpawn.rotation); /*....as GameObject; //<--when creating this entity, create it as a game object*/
            laserSfx.Play();

        }
    }

    //Fixed update used applying forces
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        //y is zero since ball isn't moving up off the plane
        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);

        //apply a force to sphere based on received Input
        rb.velocity = movement * speed; //<-- don't use rb.additive, will push player off sceen 

        //limit the player movement to the boundaries of the screen
        rb.position = new Vector3( 
            Mathf.Clamp(rb.position.x, bounds.xMin, bounds.xMax), 
            0.0f,
            Mathf.Clamp(rb.position.z, bounds.zMin, bounds.zMax)
            );

        //adds tilting force when moving ship
        rb.rotation = Quaternion.Euler(0.0f, 0.0f, rb.velocity.x * -tilt); //-tilt corrects tilt direction with input
    }
}